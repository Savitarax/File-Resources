﻿namespace AppxPackagesManager.Models {
    internal class PackageType {
        public static string AllPackages = "All Packages";
        public static string Packages = "Packages";
        public static string NonRemovablePackages = "Non-Removable";
        public static string FrameworkPackages = "Framework";
    }
}
